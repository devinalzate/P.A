/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

/**
 *
 * @author Estudiantes
 */
public class Cliente extends Persona{
    private String proFavorito;
    private int compraPromedio;

    public Cliente(String proFavorito, int compraPromedio, String nombre, String direccion) {
        super(nombre, direccion);
        this.proFavorito = proFavorito;
        this.compraPromedio = compraPromedio;
    }

    public String getProFavorito() {
        return proFavorito;
    }

    public void setProFavorito(String proFavorito) {
        this.proFavorito = proFavorito;
    }

    public int getCompraPromedio() {
        return compraPromedio;
    }

    public void setCompraPromedio(int compraPromedio) {
        this.compraPromedio = compraPromedio;
    }
    
    
    
}
