/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

/**
 *
 * @author Estudiantes
 */
public class Persona {
    private String nombre;
    private String direcccion;

    public Persona(String nombre,String direccion) {
        this.nombre = nombre;
        this.direcccion = direccion;
    }
    
    
    
    
}
